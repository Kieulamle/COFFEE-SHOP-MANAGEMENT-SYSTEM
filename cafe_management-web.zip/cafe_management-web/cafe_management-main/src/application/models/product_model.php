<?php
class Product_model extends CI_Model {
   // public function get_list()
    //{
    //        $query = $this->db->get('product', 25);
      //      return $query->result_array();
    //}
    public function get_list()
{
    $this->db->where('status', 'active');
    $query = $this->db->get('product', 25);
    return $query->result_array();
}



}